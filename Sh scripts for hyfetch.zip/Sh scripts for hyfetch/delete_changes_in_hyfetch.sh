##The deleting hyfetch.json
while true; do
    read -p "Do you want delete datas in hyfetch " yn
    case $yn in
        [Yy]* ) ./v.sh;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac
done