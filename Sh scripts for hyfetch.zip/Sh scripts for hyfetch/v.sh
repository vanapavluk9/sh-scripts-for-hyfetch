## The "y" script

echo "Deleted!"

cd ..

rm .config/hyfetch.json