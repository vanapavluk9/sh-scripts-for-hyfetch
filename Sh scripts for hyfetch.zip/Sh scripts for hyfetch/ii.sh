## Hyfetch install script
sudo apt install python3 python3-pip hyfetch
sudo pip3 install hyfetch