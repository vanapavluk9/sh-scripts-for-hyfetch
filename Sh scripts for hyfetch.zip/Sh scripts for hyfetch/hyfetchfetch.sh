## The hyfetch settings checker for linux if saving changes in JSON format


echo "The hyfetch settings checker for linux if saving changes in JSON format"

cd ..

cat .config/hyfetch.json
