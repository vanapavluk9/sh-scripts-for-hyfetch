while true; do
    read -p "Install hyfetch " yn
    case $yn in
        [Yy]* ) ./ii.sh;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac
done